namespace MySort
{
    class Sort
    {
    public:
		static int * BubbleSort(int *,int,int);
		static int * InsertionSort(int *,int,int);
		static int * SelectionSort(int *,int,int);
		static int * QuickSort(int *,int);
	};
}
