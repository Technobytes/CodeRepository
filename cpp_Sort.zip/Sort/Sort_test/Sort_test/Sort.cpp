#include<sortlib.h>
#include<stdio.h>
#include<stdlib.h>
#include<iostream>
using namespace std;
using namespace MySort;
 int main()
 {
	int s = 10;
	int i=0,a[10],*b,choice=0;
	cout<<"Enter the numbers for array:"<<endl;
	for(i=0;i<s;i++)
	{
		cout<<"Enter num: ";
		cin >> a[i];
	}
	int Selectsort = 0;
	cout<<"\n1. Ascending Order\n2. Descending Order\n(Not Applicable for quick sort)\n"<<endl;
	cout << "Enter your choice: ";
	cin >> choice;
	cout<<"\n1. Bubble Sort\n2. Insertion Sort\n3. Selection Sort\n4. Quick Sort"<<endl;
	cout << "\nEnter your choice: ";
	cin >> Selectsort;
	switch(Selectsort)
	{
	case 1:
		if(choice == 1)
			b = Sort::BubbleSort(a,s,1);//takes 3 arguments 1. array 2. Size of the array 3. ascending or descending order(if 1->ascending, if 2->descending)
		else if(choice == 2)
			b = Sort::BubbleSort(a,s,2);//takes 3 arguments 1. array 2. Size of the array 3. ascending or descending order(if 1->ascending, if 2->descending)
		else
			cout<<"select ascending or descending"<<endl;
		break;
	case 2:
		if(choice == 1)
			b = Sort::InsertionSort(a,s,1);//takes 3 arguments 1. array 2. Size of the array 3. ascending or descending order(if 1->ascending, if 2->descending)
		else if(choice == 2)
			b = Sort::InsertionSort(a,s,2);//takes 3 arguments 1. array 2. Size of the array 3. ascending or descending order(if 1->ascending, if 2->descending)
		else
			cout<<"select ascending or descending"<<endl;
		break;
	case 3:
		if(choice == 1)
			b = Sort::SelectionSort(a,s,1);//takes 3 arguments 1. array 2. Size of the array 3. ascending or descending order(if 1->ascending, if 2->descending)
		else if(choice == 2)
			b = Sort::SelectionSort(a,s,2); //takes 3 arguments 1. array 2. Size of the array 3. ascending or descending order(if 1->ascending, if 2->descending)
		else
			cout<<"select ascending or descending"<<endl;
		break;
	case 4:
		b = Sort::QuickSort(a,s); //takes only 2 arguments 1. array 2. Size of the array
		break;
	}
	cout<<"\nSorted array"<<endl;
	for(i=0;i<s;i++)
	{
		printf("%d\n",b[i]);
	}
	system("pause");
 }