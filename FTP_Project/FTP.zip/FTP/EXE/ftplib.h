namespace FTP
{
	class ftp
	{
	public:
		static int GetValues(char[], char[], char[], char[],int);
	};

}
