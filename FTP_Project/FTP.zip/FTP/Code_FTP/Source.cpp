#include<stdio.h>
#include<ftplib.h>
#include<iostream>
using namespace std;
using namespace FTP;
int main()
{
	//Below function takes 5 arguments 
	//ftp::GetValues(HOST_NAME, USER_NAME,PASSWORD, FILE_TO_BE_UPLOADED/DOWNLOADED, WANT_TO_DOWNLOAD or UPLOAD)
	//WANT_TO_DOWNLOAD or UPLOAD = 1 -> Downloades the file from ftp server
	//WANT_TO_DOWNLOAD or UPLOAD = 2 -> Uploades the file to ftp server
	//WANT_TO_DOWNLOAD or UPLOAD = any other value -> return 0
	int a = ftp::GetValues("localhost","suraj","password","a.txt",1);
	if (a == 0)
		cout << "error" << endl;
	if (a == 1)
		cout << "success" << endl;
	//system("pause");
}